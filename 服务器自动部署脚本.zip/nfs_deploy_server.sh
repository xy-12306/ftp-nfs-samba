#!/bin/bash

# 更改镜像源
curl -o /etc/yum.repos.d/CentOS-Base.repo https://mirrors.aliyun.com/repo/Centos-7.repo
if [ $? -ne 0 ]; then
    echo "配置yum源失败,请检查网络连接或源地址是否正确。" >> /tmp/samba_deploy.log
    exit 1
fi

yum makecache
if [ $? -ne 0 ]; then
    echo "更新yum缓存失败,请检查网络连接或yum配置。" >> /tmp/samba_deploy.log
    exit 1
fi

# 关闭防火墙
systemctl stop firewalld
if [ $? -ne 0 ]; then
    echo "关闭防火墙失败，请检查相关权限或系统状态。" >> /tmp/nfs_deploy.log
    exit 1
fi

# 禁止防火墙开机自启动
systemctl disable firewalld
if [ $? -ne 0 ]; then
    echo "禁止防火墙开机自启动失败，请检查相关权限或系统状态。" >> /tmp/nfs_deploy.log
    exit 1
fi

# 查看防火墙状态
systemctl status firewalld >> /tmp/nfs_deploy.log


# 将 SELINUX 行的值改为 disabled
sed -i 's/SELINUX=enforcing/SELINUX=disabled/' /etc/sysconfig/selinux
if [ $? -ne 0 ]; then
    echo "修改 SELinux 配置失败，请检查文件权限或配置内容。" >> /tmp/nfs_deploy.log
    exit 1
fi


# 服务端安装 nfs-utils 与 rpcbind
yum -y install nfs-utils rpcbind
if [ $? -ne 0 ]; then
    echo "安装 nfs-utils 与 rpcbind 服务失败，请检查网络连接或软件源配置。" >> /tmp/nfs_deploy.log
    exit 1
fi


# 创建文件夹
mkdir -p /public
if [ $? -ne 0 ]; then
    echo "创建 /public 目录失败，请检查文件系统权限或目录结构。" >> /tmp/nfs_deploy.log
    exit 1
fi
mkdir -p /protected
if [ $? -ne 0 ]; then
    echo "创建 /protected 目录失败，请检查文件系统权限或目录结构。" >> /tmp/nfs_deploy.log
    exit 1
fi


# 编辑 nfs 配置文件
cat << EOF > /etc/exports
/public 192.168.1.3/24(rw)
/protected 192.168.1.3/24(rw)
EOF
if [ $? -ne 0 ]; then
    echo "编辑 /etc/exports 配置文件失败，请检查文件权限或配置内容。" >> /tmp/nfs_deploy.log
    exit 1
fi


# 使配置生效
exportfs -r
if [ $? -ne 0 ]; then
    echo "使 nfs 配置生效失败，请检查相关配置或权限。" >> /tmp/nfs_deploy.log
    exit 1
fi


# 按照顺序启动服务
systemctl start rpcbind
if [ $? -ne 0 ]; then
    echo "启动 rpcbind 服务失败，请检查相关权限或系统状态。" >> /tmp/nfs_deploy.log
    exit 1
fi
systemctl start nfs
if [ $? -ne 0 ]; then
    echo "启动 nfs 服务失败，请检查相关权限或系统状态。" >> /tmp/nfs_deploy.log
    exit 1
fi


# 设置开机自启动
systemctl enable rpcbind
if [ $? -ne 0 ]; then
    echo "设置 rpcbind 服务开机自启动失败，请检查相关权限或系统状态。" >> /tmp/nfs_deploy.log
    exit 1
fi
systemctl enable nfs
if [ $? -ne 0 ]; then
    echo "设置 nfs 服务开机自启动失败，请检查相关权限或系统状态。" >> /tmp/nfs_deploy.log
    exit 1
fi


# 校验配置
showmount -e localhost
if [ $? -ne 0 ]; then
    echo "校验 nfs 配置失败，请检查相关配置或权限。" >> /tmp/nfs_deploy.log
    exit 1
fi


# 使用 rpcinfo -p 查看并验证
rpcinfo -p
if [ $? -ne 0 ]; then
    echo "rpcinfo -p 查看并验证失败，请检查相关配置或权限。" >> /tmp/nfs_deploy.log
    exit 1
fi

# 输出部署成功信息
echo "NFS 服务端部署成功!请去配置客户端。"