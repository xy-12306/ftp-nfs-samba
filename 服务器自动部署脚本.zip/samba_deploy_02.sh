#!/bin/bash

# 配置阿里云yum源并更新缓存
curl -o /etc/yum.repos.d/CentOS-Base.repo https://mirrors.aliyun.com/repo/Centos-7.repo
if [ $? -ne 0 ]; then
    echo "配置yum源失败,请检查网络连接或源地址是否正确。" >> /tmp/samba_deploy.log
    exit 1
fi
yum makecache
if [ $? -ne 0 ]; then
    echo "更新yum缓存失败,请检查网络连接或yum配置。" >> /tmp/samba_deploy.log
    exit 1
fi

#安装expect
yum install -y expect
if [ $? -ne 0 ]; then
    echo "安装expect失败,请检查网络连接或软件源配置。" >> /tmp/samba_deploy.log
    exit 1
fi

# 关闭防火墙
systemctl stop firewalld
if [ $? -ne 0 ]; then
    echo "关闭防火墙失败，请检查相关权限或系统状态。" >> /tmp/samba_deploy.log
    exit 1
fi

# 禁止防火墙开机自启动
systemctl disable firewalld
if [ $? -ne 0 ]; then
    echo "禁止防火墙开机自启动失败，请检查相关权限或系统状态。" >> /tmp/samba_deploy.log
    exit 1
fi

# 查看防火墙状态
systemctl status firewalld >> /tmp/samba_deploy.log

# 关闭 SELinux
setenforce 0
if [ $? -ne 0 ]; then
    echo "关闭 SELinux 失败，请检查 SELinux 相关配置或权限。" >> /tmp/samba_deploy.log
    exit 1
fi

# 修改 SELinux 配置
sed -i 's/SELINUX=enforcing/SELINUX=disabled/' /etc/sysconfig/selinux
if [ $? -ne 0 ]; then
    echo "修改 SELinux 配置失败，请检查文件权限或配置内容。" >> /tmp/samba_deploy.log
    exit 1
fi

# 安装 samba
yum install -y samba
if [ $? -ne 0 ]; then
    echo "安装 samba 失败，可能是网络问题或软件源问题，请检查网络连接或软件源配置。" >> /tmp/samba_deploy.log
    exit 1
fi

# 启动 samba 并设置开机自启动
systemctl enable smb
if [ $? -ne 0 ]; then
    echo "设置 smb 服务开机自启动失败，请检查相关权限或系统状态。" >> /tmp/samba_deploy.log
    exit 1
fi
systemctl enable nmb
if [ $? -ne 0 ]; then
    echo "设置 nmb 服务开机自启动失败，请检查相关权限或系统状态。" >> /tmp/samba_deploy.log
    exit 1
fi
systemctl start smb
if [ $? -ne 0 ]; then
    echo "启动 smb 服务失败，请检查相关权限或系统状态。" >> /tmp/samba_deploy.log
    exit 1
fi
systemctl start nmb
if [ $? -ne 0 ]; then
    echo "启动 nmb 服务失败，请检查相关权限或系统状态。" >> /tmp/samba_deploy.log
    exit 1
fi

# 创建共享文件夹及测试文件
mkdir -p /smb/share
if [ $? -ne 0 ]; then
    echo "创建共享文件夹失败，请检查文件系统权限或目录结构。" >> /tmp/samba_deploy.log
    exit 1
fi
chmod 777 /smb/share
if [ $? -ne 0 ]; then
    echo "修改共享文件夹权限失败，请检查权限设置或目录权限。" >> /tmp/samba_deploy.log
    exit 1
fi
cd /smb/share
if [ $? -ne 0 ]; then
    echo "进入共享文件夹失败，请检查目录是否存在或权限问题。" >> /tmp/samba_deploy.log
    exit 1
fi
echo 'Hello World' > 1.txt
if [ $? -ne 0 ]; then
    echo "创建测试文件失败，请检查文件系统权限或目录权限。" >> /tmp/samba_deploy.log
    exit 1
fi

# 配置 samba
cat << EOF >> /etc/samba/smb.conf
[share]
        comment = share
        path =/smb/share
        browseable = yes
        read only = no
        writeable = yes
        public = Yes
EOF
if [ $? -ne 0 ]; then
    echo "修改 samba 配置文件失败，请检查文件权限或配置内容。" >> /tmp/samba_deploy.log
    exit 1
fi

# 添加用户并设置密码
useradd user01
if [ $? -ne 0 ]; then
    echo "user01 用户已完成部署,请勿重复部署！" >> /tmp/samba_deploy.log
    exit 1
fi

# 使用 expect 自动设置 samba 用户密码
expect << EOF
spawn smbpasswd -a user01
expect "New SMB password:"
send "123456\r"
expect "Retype new SMB password:"
send "123456\r"
expect eof
EOF
if [ $? -ne 0 ]; then
    echo "设置 samba 用户密码失败，请检查 samba 服务状态或 expect 脚本。" >> /tmp/samba_deploy.log
    exit 1
fi

# 重启服务
systemctl restart smb
if [ $? -ne 0 ]; then
    echo "重启 smb 服务失败，请检查相关权限或系统状态。" >> /tmp/samba_deploy.log
    exit 1
fi
systemctl restart nmb
if [ $? -ne 0 ]; then
    echo "重启 nmb 服务失败，请检查相关权限或系统状态。" >> /tmp/samba_deploy.log
    exit 1
fi

# 查看服务是否启动
systemctl status smb >> /tmp/samba_deploy.log
systemctl status nmb >> /tmp/samba_deploy.log

# 输出设置的用户名和密码
echo "Samba 服务已自动部署成功！"
echo "用户名是: user01"
echo "密码是: 123456"

# 获取当前主机 IP 地址并输出
ip_address=$(ip addr | grep 'inet ' | grep -v '127.0.0.1' | awk '{print $2}' | cut -d '/' -f1)
echo "当前主机 IP 地址为: $ip_address"