#!/bin/bash

# 关闭防火墙
systemctl stop firewalld
if [ $? -ne 0 ]; then
    echo "关闭防火墙失败，请检查相关权限或系统状态。" >> /tmp/nfs_client_deploy.log
    exit 1
fi


# 禁止防火墙开机自启动
systemctl disable firewalld
if [ $? -ne 0 ]; then
    echo "禁止防火墙开机自启动失败，请检查相关权限或系统状态。" >> /tmp/nfs_client_deploy.log
    exit 1
fi


# 查看防火墙状态
systemctl status firewalld >> /tmp/nfs_client_deploy.log


# 安装 nfs-utils 与 rpcbind
yum -y install nfs-utils rpcbind
if [ $? -ne 0 ]; then
    echo "安装 nfs-utils 与 rpcbind 服务失败，请检查网络连接或软件源配置。" >> /tmp/nfs_client_deploy.log
    exit 1
fi


# 查看服务端挂载的目录
showmount -e 192.168.1.3
if [ $? -ne 0 ]; then
    echo "查看服务端挂载目录失败，请检查网络连接或服务端配置。" >> /tmp/nfs_client_deploy.log
    exit 1
fi


# 创建新文件夹
mkdir -p /mnt/public
if [ $? -ne 0 ]; then
    echo "创建 /mnt/public 目录失败，请检查文件系统权限或目录结构。" >> /tmp/nfs_client_deploy.log
    exit 1
fi
mkdir -p /mnt/data
if [ $? -ne 0 ]; then
    echo "创建 /mnt/data 目录失败，请检查文件系统权限或目录结构。" >> /tmp/nfs_client_deploy.log
    exit 1
fi


# 第二种方法，可以开机自启自动挂载
cat << EOF >> /etc/fstab
192.168.1.3:/public  /mnt/public    nfs  defaults  0 0
192.168.1.3:/protected /mnt/data    nfs  defaults  0 1
EOF
if [ $? -ne 0 ]; then
    echo "编辑 /etc/fstab 配置文件失败，请检查文件权限或配置内容。" >> /tmp/nfs_client_deploy.log
    exit 1
fi


# 使 /etc/fstab 配置生效
mount -a
if [ $? -ne 0 ]; then
    echo "使 /etc/fstab 配置生效失败，请检查配置文件或系统状态。" >> /tmp/nfs_client_deploy.log
    exit 1
fi


# 查看挂载盘
df -h >> /tmp/nfs_client_deploy.log

# 输出 df -h 的结果
echo "[root@localhost ~]# df -h"
df -h
