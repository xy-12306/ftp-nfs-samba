#!/bin/bash

# 更改镜像源
curl -o /etc/yum.repos.d/CentOS-Base.repo https://mirrors.aliyun.com/repo/Centos-7.repo
if [ $? -ne 0 ]; then
    echo "配置yum源失败,请检查网络连接或源地址是否正确。" >> /tmp/samba_deploy.log
    exit 1
fi

yum makecache
if [ $? -ne 0 ]; then
    echo "更新yum缓存失败,请检查网络连接或yum配置。" >> /tmp/samba_deploy.log
    exit 1
fi

# 关闭防火墙
systemctl stop firewalld
if [ $? -ne 0 ]; then
    echo "关闭防火墙失败，请检查相关权限或系统状态。" >> /tmp/ftp_deploy.log
    exit 1
fi

# 禁止防火墙开机自启动
systemctl disable firewalld
if [ $? -ne 0 ]; then
    echo "禁止防火墙开机自启动失败，请检查相关权限或系统状态。" >> /tmp/ftp_deploy.log
    exit 1
fi

# 查看防火墙状态
systemctl status firewalld >> /tmp/ftp_deploy.log


# 关闭 SELinux
setenforce 0
if [ $? -ne 0 ]; then
    echo "关闭 SELinux 失败，请检查 SELinux 相关配置或权限。" >> /tmp/ftp_deploy.log
    exit 1
fi

# 修改 SELinux 配置
sed -i 's/SELINUX=enforcing/SELINUX=disabled/' /etc/sysconfig/selinux
if [ $? -ne 0 ]; then
    echo "修改 SELinux 配置失败，请检查文件权限或配置内容。" >> /tmp/ftp_deploy.log
    exit 1
fi


# 安装 vsftpd 服务
yum -y install vsftpd
if [ $? -ne 0 ]; then
    echo "安装 vsftpd 服务失败，请检查网络连接或软件源配置。" >> /tmp/ftp_deploy.log
    exit 1
fi


# 检查是否安装成功
if ! rpm -qa | grep vsftpd &>/dev/null; then
    echo "vsftpd 服务安装失败，请检查安装日志或软件源。" >> /tmp/ftp_deploy.log
    exit 1
fi


# 修改配置文件
sed -i 's/#anon_upload_enable=YES/anon_upload_enable=YES/g' /etc/vsftpd/vsftpd.conf
if [ $? -ne 0 ]; then
    echo "修改 anon_upload_enable 配置失败，请检查文件权限或配置内容。" >> /tmp/ftp_deploy.log
    exit 1
fi
sed -i 's/#anon_mkdir_write_enable=YES/anon_mkdir_write_enable=YES/g' /etc/vsftpd/vsftpd.conf
if [ $? -ne 0 ]; then
    echo "修改 anon_mkdir_write_enable 配置失败，请检查文件权限或配置内容。" >> /tmp/ftp_deploy.log
    exit 1
fi


# 创建目录
mkdir -p /var/ftp/jimu
if [ $? -ne 0 ]; then
    echo "创建目录 /var/ftp/jimu 失败，请检查文件系统权限或目录结构。" >> /tmp/ftp_deploy.log
    exit 1
fi


# 修改权限
chown ftp /var/ftp/jimu
if [ $? -ne 0 ]; then
    echo "修改 /var/ftp/jimu 目录权限失败，请检查权限设置或目录权限。" >> /tmp/ftp_deploy.log
    exit 1
fi


# 显示目录信息
ls -l -d /var/ftp/jimu >> /tmp/ftp_deploy.log


# 允许匿名用户写入文件
setsebool -P allow_ftpd_anon_write on
if [ $? -ne 0 ]; then
    echo "设置 allow_ftpd_anon_write 失败，请检查 SELinux 相关配置或权限。" >> /tmp/ftp_deploy.log
    exit 1
fi


# 查看 SELinux 布尔值状态
getsebool -a | grep ftp >> /tmp/ftp_deploy.log


# 修改上下文
chcon -t public_content_rw_t /var/ftp/jimu/
if [ $? -ne 0 ]; then
    echo "修改目录上下文失败，请检查 SELinux 相关配置或权限。" >> /tmp/ftp_deploy.log
    exit 1
fi


# 显示修改后的目录上下文
ls -Zd /var/ftp/jimu/ >> /tmp/ftp_deploy.log


# 查看 SELinux 状态
getenforce >> /tmp/ftp_deploy.log


# 重启 vsftpd 服务
systemctl restart vsftpd.service
if [ $? -ne 0 ]; then
    echo "重启 vsftpd 服务失败，请检查相关权限或系统状态。" >> /tmp/ftp_deploy.log
    exit 1
fi


# 输出部署成功信息
echo "FTP 服务部署成功！"

# 获取当前主机 IP 地址并输出
ip_address=$(ip addr | grep 'inet ' | grep -v '127.0.0.1' | awk '{print $2}' | cut -d '/' -f1)
echo "当前主机 IP 地址为: $ip_address"